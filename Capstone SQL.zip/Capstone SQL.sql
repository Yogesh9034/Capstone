/*SELECT * FROM project_schema.`amazon.yogi` LIMIT 0, 1000
1.What is the count of distinct cities in the dataset?
SELECT COUNT(DISTINCT city) AS distinct_city_count
FROM project_schema.`amazon.yogi`; 

2.For each branch, what is the corresponding city?
SELECT branch, city
FROM project_schema.`amazon.yogi`
GROUP BY branch, city;

3.What is the count of distinct product lines in the dataset?
SELECT COUNT(DISTINCT `product line`) AS distinct_product_line_count
FROM project_schema.`amazon.yogi`;

4.Which payment method occurs most frequently?
SELECT payment, COUNT(*) AS method_count
FROM project_schema.`amazon.yogi`
GROUP BY payment
ORDER BY method_count DESC
LIMIT 1;

5.Which product line has the highest sales?
SELECT `product line`, SUM(total) AS total_sales
FROM project_schema.`amazon.yogi`
GROUP BY `product line`
ORDER BY total_sales DESC
LIMIT 1;

6.How much revenue is generated each month?
SELECT DATE_FORMAT(`date`, '%Y-%m') AS 'year_month', SUM(total) AS monthly_revenue
FROM project_schema.`amazon.yogi`
GROUP BY DATE_FORMAT(`date`, '%Y-%m')
ORDER BY 'year_month';

7.In which month did the cost of goods sold reach its peak?
-- Find the month with the highest cost of goods sold in the orders table
SELECT DATE_FORMAT(`date`, '%Y-%m') AS'year_month', SUM(cogs) AS total_cogs
FROM  project_schema.`amazon.yogi`
GROUP BY DATE_FORMAT(`date`, '%Y-%m')
ORDER BY total_cogs DESC
LIMIT 1;

8.Which product line generated the highest revenue?
SELECT `product line`, SUM(total) AS total_revenue
FROM project_schema.`amazon.yogi`
GROUP BY `product line`
ORDER BY total_revenue DESC
LIMIT 1;

9.In which city was the highest revenue recorded?
SELECT city, SUM(total) AS total_revenue
FROM project_schema.`amazon.yogi`
GROUP BY city
ORDER BY total_revenue DESC
LIMIT 1;

10.Which product line incurred the highest Value Added Tax?
SELECT 'product line', SUM(`Tax 5%`) AS total_tax
FROM project_schema.`amazon.yogi`
GROUP BY  'product line'

11.For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."
SELECT *,
       CASE WHEN total_sales > avg_sales THEN 'Good'
            ELSE 'Bad'
       END AS sales_status
FROM (
    SELECT 'product line',
           SUM(total) AS total_sales,
           AVG(SUM(total)) OVER () AS avg_sales
    FROM project_schema.`amazon.yogi`
    GROUP BY 'product line'
    ) AS subquery
ORDER BY total_sales DESC
LIMIT 1;
    
    12.Identify the branch that exceeded the average number of products sold.
SELECT branch, total_products_sold, avg_products_sold
FROM (
    SELECT branch,
           SUM(quantity) AS total_products_sold,
           AVG(SUM(quantity)) OVER () AS avg_products_sold
    FROM project_schema.`amazon.yogi`
    GROUP BY branch
) AS subquery
WHERE total_products_sold > avg_products_sold;

13.Which product line is most frequently associated with each gender?
WITH ProductLineFrequency AS (
    SELECT gender, 'product line', COUNT(*) AS frequency
    FROM project_schema.`amazon.yogi`
    GROUP BY gender, 'product line'
),
MaxFrequency AS (
    SELECT gender, MAX(frequency) AS max_frequency
    FROM ProductLineFrequency
    GROUP BY gender
)
SELECT p.gender, 'p.product line', p.frequency
FROM ProductLineFrequency p
JOIN MaxFrequency m
ON p.gender = m.gender AND p.frequency = m.max_frequency;

14.Calculate the average rating for each product line.
SELECT 'product line', AVG(rating) AS average_rating
FROM project_schema.`amazon.yogi`
GROUP BY 'product line';

15.Count the sales occurrences for each time of day on every weekday.
SELECT 
    DAYNAME(date) AS weekday, 
    HOUR(time) AS hour_of_day, 
    COUNT(*) AS sales_occurrences
FROM project_schema.`amazon.yogi`
GROUP BY DAYNAME(date), HOUR(time)
ORDER BY weekday, hour_of_day;

16.Identify the customer type contributing the highest revenue.
SELECT 'customer', SUM(total) AS total_revenue
FROM project_schema.`amazon.yogi`
GROUP BY 'customer'
ORDER BY total_revenue DESC
LIMIT 1;

17.Determine the city with the highest VAT percentage.
SELECT city, MAX('Tax 5%') AS max_vat
FROM project_schema.`amazon.yogi`
GROUP BY city
ORDER BY max_vat DESC
LIMIT 1;

18.Identify the customer type with the highest VAT payments.
SELECT 'customer', SUM('Tax 5%') AS total_vat_payments
FROM project_schema.`amazon.yogi`
GROUP BY 'customer'
ORDER BY total_vat_payments DESC
LIMIT 1;

19.What is the count of distinct customer types in the dataset?
SELECT COUNT(DISTINCT 'customer') AS distinct_customer_types

20.What is the count of distinct payment methods in the dataset?
SELECT COUNT(DISTINCT 'payment') AS distinct_payment_methods
FROM project_schema.`amazon.yogi`;

21.Which customer type occurs most frequently?
SELECT 'customer', COUNT(*) AS frequency
FROM project_schema.`amazon.yogi`
GROUP BY 'customer'
ORDER BY frequency DESC
LIMIT 1;

22.Identify the customer type with the highest purchase frequency.
SELECT 'customer', COUNT(DISTINCT 'Invoice ID') AS purchase_frequency
FROM project_schema.`amazon.yogi`
GROUP BY 'customer'
ORDER BY purchase_frequency DESC
LIMIT 1;

23.Determine the predominant gender among customers.
SELECT gender, COUNT(*) AS gender_count
FROM project_schema.`amazon.yogi`
WHERE gender IS NOT NULL
GROUP BY gender
ORDER BY gender_count DESC
LIMIT 1;

24.Examine the distribution of genders within each branch.
SELECT branch, gender, COUNT(*) AS gender_count
FROM project_schema.`amazon.yogi`
WHERE gender IS NOT NULL
GROUP BY branch, gender
ORDER BY branch, gender_count DESC;

25.Identify the time of day when customers provide the most ratings.
SELECT HOUR(time) AS hour_of_day, COUNT(*) AS rating_count
FROM project_schema.`amazon.yogi`
WHERE rating IS NOT NULL
GROUP BY HOUR(time)
ORDER BY rating_count DESC
LIMIT 1;

26.Determine the time of day with the highest customer ratings for each branch.
SELECT branch, HOUR(time) AS hour_of_day, COUNT(*) AS rating_count
FROM project_schema.`amazon.yogi`
WHERE rating IS NOT NULL
GROUP BY branch, HOUR(time)
ORDER BY branch, rating_count DESC;

27.Identify the day of the week with the highest average ratings.
SELECT DAYNAME(date) AS day_of_week, AVG(rating) AS avg_rating
FROM project_schema.`amazon.yogi`
WHERE rating IS NOT NULL
GROUP BY DAYNAME(date)
ORDER BY avg_rating DESC
LIMIT 1;

28.Determine the day of the week with the highest average ratings for each branch.*/
SELECT branch, DAYNAME(date) AS day_of_week, AVG(rating) AS avg_rating
FROM project_schema.`amazon.yogi`
WHERE rating IS NOT NULL
GROUP BY branch, DAYNAME(date)
ORDER BY branch, avg_rating DESC; 



























































































