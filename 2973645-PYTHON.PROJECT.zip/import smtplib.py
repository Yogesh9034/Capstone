import smtplib
from tkinter import *
from tkinter import messagebox
import threading
import time

# Function to generate a 6-digit OTP
def generate_otp():
    randomcode = ''.join(str(random.randint(0, 9)) for _ in range(6))
    return randomcode

# Function to send OTP via email
def sendOTP():
  global code,attempts
  receiver = receiverMail.get()
  code = generateOTP()
    
  server =smtplib.SMTP('smpt.gmail.com',587)
  server.starttls()
  server.login(sender, receiver, msg)
  server.quit()

  msg ='Hello! \n This is your OTP:' + code
  server.sendmail(sender, receiver, msg)
  server.quit()

  attempts = 0
   
    #checl otp validity
  def check_otp():
    global attempts
    entered_code = code_entry.get()
    if entered_code == code:
        messagebox.showinfo('Success', 'Successful verification!')
    else:
        attempts += 1
        if attempts >= max_attempts:
            messagebox.showinfo('Limit Exceeded', 'You have reached the maximum OTP entry limit. Please try again later.')
            send_otp_button.config(state=tk.DISABLED)
        else:
            messagebox.showinfo('Error', 'Invalid OTP! Please try again.')
            

            #gui
            otp = Tk()
            otp.title('OTP verification')
            otp.geometry('750*400')
            otp.config(bg='#FFF1DC')

            sender = 'mandhakavaliyogesh@gmail.com'
            password = 'kaea rmyk tnjd zywx'
            code = ''
            attempts = 0
            max_attempts = 3

            mailMsg = label(otp, text="E-Mail", justify=LEFT, bg='#fff1dc', font=('Arial', 16))
            mail.Msg.place(x=15, y=40)

            receiverMail = Entry(otp, width=35,font=("Arial", 20), borderwidth=0) 
            receiverMail.place(x=100,y=40)

            sendOTPButton = Button(otp, text="send OTP", width=8, height=1, font=("Arial", 20), borderwidth=0, bg="#aa5656", fg="black")
            sendOTPButton.place(x=280, y=100)

            otpMsg = Label(otp, text="otp", bg="#FFF1DC", font=('Arial', 16))
            otpMsg.place(x=15, y=210)

            codeEntry = Entry(otp, width=6, font=("Arial", 20), borderwidth=0)
            codeEntry.place(x=100, y=210)

            verifyButton = Button(otp, text="verify", width=8, height=1, font=("Arail", 20), borderwidth='#aa5656', fg="black")
            verifyButton.place(x=280, y=280)

            otp.mainloop()